﻿Public Class Form1
    Private Sub Img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\Fotos"
                .ShowDialog()
                diretorio = .FileName
                img_foto.Load(diretorio)
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Conecta_banco()
        Carregar_dados()
        Carregar_tipo()

        cmb_campo.Items.Clear()
        cmb_campo.Items.Add("nome_produto")
        cmb_campo.Items.Add("marca_fabricante")
        cmb_campo.SelectedIndex = 0
    End Sub

    Private Sub btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        Try
            sql = $"select * from tb_produtos where numero_lote = '{txt_lote.Text}'"
            rs = db.Execute(sql)

            If rs.EOF = True Then
                Dim precoCusto As String = txt_preco_custo.Text.Replace(",", ".")
                Dim precoVenda As String = txt_preco_venda.Text.Replace(",", ".")

                Dim dataLote As String = cmb_data_lote.Value.ToString("yyyy-MM-dd")

                sql = $"insert into tb_produtos (nome_produto, descricao_produto, data_lote, marca_fabricante, categoria, quantidade, preco_custo, preco_venda, foto, numero_lote) " &
                  $"values ('{txt_nome.Text.ToUpper()}', '{txt_descricao.Text}', '{dataLote}' , '{txt_marca_fabricante.Text.ToUpper()}', '{cmb_categoria.Text}', '{qtde.Text}', '{precoCusto}', '{precoVenda}', '{diretorio}', '{txt_lote.Text}')"

                rs = db.Execute(sql)

                MsgBox("Cadastro Realizado com Sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

                Limpar_cadastro()
                Carregar_dados()

            Else
                MsgBox("Lote já Cadastrado!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "AVISO")
            End If

        Catch ex As Exception
            MsgBox("ERRO AO GRAVAR: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ERRO")
        End Try
    End Sub

    Private Sub txt_nome_LostFocus(sender As Object, e As EventArgs)
        Try
            sql = $"select * from tb_produtos where nome_produto = '{txt_nome.Text}'"
            rs = db.Execute(sql)

            If rs.EOF = False Then
                txt_descricao.Text = rs.Fields("descricao_produto").Value
                cmb_data_lote.Value = rs.Fields("data_lote").Value
                txt_marca_fabricante.Text = rs.Fields("marca_fabricante").Value
                cmb_categoria.Text = rs.Fields("categoria").Value
                qtde.Text = rs.Fields("quantidade").Value
                txt_preco_custo.Text = rs.Fields("preco_custo").Value
                txt_preco_venda.Text = rs.Fields("preco_venda").Value
                img_foto.Load(rs.Fields("foto").Value.ToString())
                txt_lote.Text = rs.Fields("numero_lote").Value
            Else
                txt_descricao.Focus()
            End If
        Catch ex As Exception
            MsgBox("Erro ao buscar dados: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub txt_nome_DoubleClick(sender As Object, e As EventArgs)
        Limpar_cadastro()
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick

    End Sub

    Private Sub txt_buscar_TextChanged(sender As Object, e As EventArgs) Handles txt_buscar.TextChanged
        Try
            sql = $"select * from tb_produtos where {cmb_campo.Text} like '%{txt_buscar.Text}%'"
            rs = db.Execute(sql)

            With dgv_dados
                .Rows.Clear()

                Do While rs.EOF = False
                    .Rows.Add(
                    rs.Fields("nome_produto").Value,
                    rs.Fields("descricao_produto").Value,
                    rs.Fields("data_lote").Value,
                    rs.Fields("marca_fabricante").Value,
                    rs.Fields("categoria").Value,
                    rs.Fields("quantidade").Value,
                    rs.Fields("preco_custo").Value,
                    rs.Fields("preco_venda").Value,
                    rs.Fields("numero_lote").Value,
                    Nothing,
                    Nothing
                )
                    rs.MoveNext()
                Loop
            End With
        Catch ex As Exception
            MsgBox("Erro ao carregar os dados: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub cmb_campo_Click(sender As Object, e As EventArgs) Handles cmb_campo.Click

    End Sub
End Class

