﻿Module Module1
    'Declaração de Variáveis Públicas
    Public diretorio As String
    Public db As New ADODB.Connection 'Variavel do Banco
    Public rs As New ADODB.Recordset 'Variavel das tabelas
    Public sql As String 'Query de leitura e  escrita
    Public cont As Integer 'Contador

    Sub Carregar_tipo()
        Try
            With Form1.cmb_campo.Items
                .Add("Nome")
                .Add("Marca/Fabricante")

            End With
            Form1.cmb_campo.SelectedIndex = 1
        Catch ex As Exception

        End Try
    End Sub

    Sub Carregar_dados()
        Try
            sql = "select * from tb_produtos order by nome_produto asc"
            rs = db.Execute(sql)

            With Form1.dgv_dados
                .Rows.Clear()

                Do While rs.EOF = False
                    .Rows.Add(
                    rs.Fields("nome_produto").Value,
                    rs.Fields("descricao_produto").Value,
                    rs.Fields("data_lote").Value,
                    rs.Fields("marca_fabricante").Value,
                    rs.Fields("categoria").Value,
                    rs.Fields("quantidade").Value,
                    rs.Fields("preco_custo").Value,
                    rs.Fields("preco_venda").Value,
                    rs.Fields("numero_lote").Value,
                    Nothing,
                    Nothing
                )

                    rs.MoveNext()
                Loop
            End With
        Catch ex As Exception
            MsgBox("Erro ao carregar os dados: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Sub Conecta_banco()
        'Conexão com o Banco de Dados SQL - SERVER
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=SQLOLEDB; Data Source=DESKTOP-J8VV85M;Initial Catalog=cad_3dsm26; trusted_connection=yes;")
            MsgBox("Conexão com o Banco de Dados realizada com Sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao conectar com o Banco de Dados: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Sub Limpar_cadastro()
        Try
            With Form1
                .txt_lote.Clear()
                .txt_nome.Clear()
                .txt_descricao.Clear()
                .cmb_data_lote.Value = DateTime.Now
                .cmb_categoria.SelectedIndex = -1
                .txt_preco_custo.Clear()
                .txt_preco_venda.Clear()
                .txt_marca_fabricante.Clear()
                .qtde.Value = 0
                .img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
                .txt_nome.Focus()

            End With
        Catch ex As Exception

        End Try

    End Sub

End Module
