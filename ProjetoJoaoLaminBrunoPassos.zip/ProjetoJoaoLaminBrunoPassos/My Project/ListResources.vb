Imports System.Reflection

Module ListResources
    Public Sub LogManifestResources()
        Dim a = Assembly.GetExecutingAssembly()
        For Each name In a.GetManifestResourceNames()
            System.Diagnostics.Debug.WriteLine("Manifest resource: " & name)
        Next
    End Sub
End Module
